package com.example.practicafinaljose

import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.practicafinaljose.databinding.ActivityAutorBinding

class Autor : AppCompatActivity() {
    lateinit var bind:ActivityAutorBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityAutorBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()

    }

}