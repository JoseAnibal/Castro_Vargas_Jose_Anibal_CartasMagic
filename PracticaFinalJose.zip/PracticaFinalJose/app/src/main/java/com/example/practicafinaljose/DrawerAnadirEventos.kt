package com.example.practicafinaljose

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import com.example.practicafinaljose.databinding.FragmentDrawerAnadirEventosBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.Period
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.CountDownLatch

class DrawerAnadirEventos : Fragment() {
    val ad by lazy{
        activity as AdminDrawer
    }
    val VBase by lazy {
        VariablesBaseDatos
    }
    var url_imagen: Uri?=null

    val formatter = DateTimeFormatter.ofPattern("yyyy-M-dd")
    var date = LocalDate.now()

    private var _binding: FragmentDrawerAnadirEventosBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentDrawerAnadirEventosBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onStart() {
        super.onStart()
        binding.cEventoTextError.visibility=View.INVISIBLE

        binding.cEventoImagen.setOnClickListener {
            obtener_url.launch("image/*")
        }

        binding.cEventoFecha.setOnClickListener {
            abrirDatePicker()
        }
    }

    override fun onResume() {
        super.onResume()
        ad.FAB_manager(4,this::InsertarEvento)
    }

    fun abrirDatePicker() {
        val newFragment = DatePickerFragment{
                day:Int, month:Int, year:Int-> fechaSeleccionada(day, month, year)
        }
        newFragment.show(parentFragmentManager, "datePicker")
    }

    fun fechaSeleccionada(day:Int, month:Int, year:Int){
        val birthDate = "$year-${month+1}-$day"
        binding.cEventoFecha.setText(birthDate)
        date = LocalDate.parse(birthDate, formatter)
    }

    fun InsertarEvento(v:View){
        if (isValid()){
            val nombre=binding.cEventoNombre.text.toString()
            val fecha=binding.cEventoFecha.text.toString()
            GlobalScope.launch(Dispatchers.IO) {
                if(!comprueboSiExiste(nombre) && !comprueboSiFechaExiste(fecha)){
                    val genero_id= VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.eventos).push().key
                    val precio=binding.cEventoPrecio.text.toString()
                    val aforo_max=binding.cEventoAforo.text.toString().toInt()
                    val aforo_ocupado=0
                    val url_imagen_firebase=if(url_imagen!=null){
                        insertoImagen(genero_id.toString(), url_imagen!!)
                    }else{
                        "https://firebasestorage.googleapis.com/v0/b/practicafinaljose-11bf8.appspot.com/o/eventodefault.jpg?alt=media&token=5e040bca-bfde-4c75-b9dc-70924746d740"
                    }

                    ad.insertoEvento(genero_id!!,nombre,url_imagen_firebase,precio,aforo_max,aforo_ocupado,fecha)
                    ad.adaptadorEvento.notifyItemChanged(ad.listaEventos.size)
                    ad.adaptadorEvento.notifyDataSetChanged()
                    ad.runOnUiThread{ad.navController.navigate(R.id.drawerEventos)}
                }
            }

        }
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    suspend fun insertoImagen(id:String,foto: Uri):String{

        lateinit var urlImagenFirebase: Uri

        urlImagenFirebase= VBase.sto_ref.child(VBase.ramaPrincipal).child(VBase.stoEventos).child(id)
            .putFile(foto).await().storage.downloadUrl.await()

        return urlImagenFirebase.toString()

    }

    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri: Uri?->
        when (uri){
            null-> {}
            else->{
                url_imagen=uri
                binding.cEventoImagen.setImageURI(url_imagen)

            }
        }
    }


    fun comprueboSiExiste(nombre:String):Boolean{
        var existe=false
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.eventos).orderByChild("nombre").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                        ad.runOnUiThread {
                            binding.cEventoNombre.error="Nombre no disponible"
                        }
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }

    fun comprueboSiFechaExiste(nombre:String):Boolean{
        var existe=false
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.eventos).orderByChild("fecha").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                        ad.runOnUiThread {
                            binding.cEventoTextError.visibility=View.VISIBLE
                            binding.cEventoTextError.text="Otro evento ya tiene esa fecha"
                        }
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }

    fun isValid():Boolean{
        var validado = true
        val checkers = listOf(
            Pair(binding.cEventoNombre, this::validoInput),
            Pair(binding.cEventoPrecio, this::validoMayor0),
            Pair(binding.cEventoAforo, this::validoMayor0),
            Pair(binding.cEventoFecha, this::validoFecha)
        )
        for(c in checkers){
            val x = c.first
            val f = c.second
            val y = f(x)
            validado = y
            if(!validado) break
        }
        return validado
    }

    fun validoInput(v: EditText):Boolean{
        var validado=true

        if(v.text.isEmpty()){
            validado=false
            v.error=getString(R.string.campoVacio)
        }

        return validado
    }

    fun validoMayor0(v: EditText):Boolean{
        var validado=true

        if(v.text.isEmpty()){
            v.setText("0")
        }

        return validado
    }

    fun validoFecha(v: EditText):Boolean{
        var validado=true
        val dias= Period.between(date, LocalDate.now()).isNegative

        if (v.text.isEmpty() || !dias){
            validado=false
            binding.cEventoTextError.text="Fecha no valida"
            binding.cEventoTextError.visibility=View.VISIBLE
            v.error="Fecha no valida"
        }
        return validado
    }
}