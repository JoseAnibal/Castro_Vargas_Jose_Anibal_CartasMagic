package com.example.practicafinaljose

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.practicafinaljose.databinding.FilaClienteCartaBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.CountDownLatch

class AdaptadorClienteCarta(val lista:List<Carta>,val contexto:Context,val tipo:String):RecyclerView.Adapter<AdaptadorClienteCarta.ViewHolder>(), Filterable {
    val VBase by lazy{
        VariablesBaseDatos
    }
    val SM by lazy{
        SharedManager((contexto as UsuarioBottomNav).applicationContext)
    }
    var filtro=0
    var listaFiltrada = lista
    class ViewHolder(val bind: FilaClienteCartaBinding):RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = FilaClienteCartaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val l = listaFiltrada[position]
        var elegida=R.drawable.nostock
        var euro=SM.EURActivado
        if(tipo==VBase.cartasObtenidas || tipo==VBase.cartasPendientes){
            holder.bind.cvCartaComprar.visibility=View.INVISIBLE
            holder.bind.cvCartaComprar.isEnabled=false
        }

        if(!euro){
            val conversion=SM.EUR_USD.toDouble()
            val precio=conversion*l.precio!!.toDouble()
            holder.bind.cvCartaPrecio.text=contexto.getString(R.string.cartaPrecioDollar,precio.toString())
        }else{
            holder.bind.cvCartaPrecio.text=contexto.getString(R.string.cartaPrecio,l.precio.toString())
        }

        with(holder.bind){
            cvCartaCategoria.text=(contexto as UsuarioBottomNav).getString(R.string.cartaCategoria,l.categoria)
            cvCartaNombre.text=l.nombre
            when(l.categoria){
                "Blanco"->elegida=R.drawable.blancopng
                "Negro"->elegida=R.drawable.negro
                "Rojo"->elegida=R.drawable.rojo
                "Verde"->elegida=R.drawable.verde
                "Azul"->elegida=R.drawable.azul
            }
            cvCartaCatImg.setImageResource(elegida)
            cvCartaComprar.setOnClickListener {
                GlobalScope.launch(Dispatchers.IO) {
                    val genero_id= VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.pedidos).push().key
                    val date = LocalDate.now().toString()
                    insertoPedido(genero_id!!,l.id!!,SM.idUsuario,VBase.pedidoDef,date,true)
                    insertoPedido(genero_id!!,l.id!!,SM.idUsuario,VBase.pedidoDef,date,false)
                }
            }
        }
        Glide.with(contexto).load(l.imagen).into(holder.bind.cvCartaImagen)

    }

    override fun getItemCount(): Int {
        return listaFiltrada.size
    }

    fun insertoPedido(id:String,idcarta:String,idusuario:String,estado:String,fecha:String,notificar:Boolean){

        val crearPedido=Pedido(id,idcarta, idusuario,estado,fecha,notificar)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.pedidos).child(id).setValue(crearPedido)

    }



    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(busqueda: CharSequence?): FilterResults {
                val texto = busqueda.toString()
                //Filtro 1, el clásico de por nombre, no hace falta pensar
                if (texto.isEmpty()) {
                    listaFiltrada = lista
                } else {
                    val listaFiltrada2 = mutableListOf<Carta>()
                    for (alu in lista) {
                        val nombreMinuscula = alu.nombre!!.lowercase(Locale.ROOT)
                        val textoMinuscula = texto.lowercase(Locale.ROOT)
                        if (nombreMinuscula.contains(textoMinuscula)) {
                            listaFiltrada2.add(alu)
                        }
                    }
                    listaFiltrada = listaFiltrada2
                }
                //FILTROS AQUI
                listaFiltrada= if(filtro!=0){
                    when(filtro){
                        1->listaFiltrada.filter { it.categoria=="Negro" }
                        2->listaFiltrada.filter { it.categoria=="Blanco" }
                        3->listaFiltrada.filter { it.categoria=="Rojo" }
                        4->listaFiltrada.filter { it.categoria=="Verde" }
                        5->listaFiltrada.filter { it.categoria=="Azul" }
                        else -> listaFiltrada
                    }
                }else{
                    listaFiltrada
                }
                val filterResults = FilterResults()
                    filterResults.values = listaFiltrada
                    return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                listaFiltrada = results?.values as MutableList<Carta>
                notifyDataSetChanged()
            }
        }
    }

}