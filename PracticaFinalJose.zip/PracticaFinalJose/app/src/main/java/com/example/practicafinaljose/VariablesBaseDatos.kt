package com.example.practicafinaljose

import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

class VariablesBaseDatos {
    companion object{
        val db_ref= FirebaseDatabase.getInstance().reference
        val sto_ref= FirebaseStorage.getInstance().reference

        //CARTASCLIENTE
        val cartasObtenidas="cartasObtenidas"
        //CARTASCLIENTEPENDIENTES
        val cartasPendientes="cartasPendientes"

        val ramaPrincipal="Tienda"

        //USUARIOS
        val usuarios="Usuarios"
        val tipoDefault="usuario"
        val stoUsuarios="usuarios"

        //CARTAS
        val cartas="Cartas"
        val stoCartas="cartas"

        //EVENTOS
        val eventos="Eventos"
        val stoEventos="eventos"
        val reservaEvento="reservaEventos"

        //PEDIDOS
        val pedidos="Pedidos"
        val pedidoDef="preparacion"
        val pedidoPreparado="preparado"

    }
}