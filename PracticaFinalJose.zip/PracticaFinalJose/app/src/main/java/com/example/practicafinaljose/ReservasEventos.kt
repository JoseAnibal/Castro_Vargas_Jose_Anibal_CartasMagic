package com.example.practicafinaljose

class ReservasEventos(val id:String?=null,
                      val idEvento:String?=null,
                      val idUsuario:String?=null)