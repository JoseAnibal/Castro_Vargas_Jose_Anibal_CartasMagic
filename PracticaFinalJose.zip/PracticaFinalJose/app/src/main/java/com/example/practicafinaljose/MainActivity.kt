package com.example.practicafinaljose

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.example.practicafinaljose.databinding.ActivityMainBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.concurrent.CountDownLatch

class MainActivity : AppCompatActivity() {
    lateinit var bind:ActivityMainBinding
    val VBase by lazy {
        VariablesBaseDatos
    }
    val SM by lazy{
        SharedManager(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)
        SM.idUsuario=getString(R.string.idUsuarioDef)
    }

    override fun onStart() {
        super.onStart()
        if(SM.modoOscuro){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        SM.idUsuario=getString(R.string.idUsuarioDef)

        bind.loginBtnLogin.setOnClickListener {
            if(validoInput(bind.loginNombre) && validoInput(bind.loginContrasena)){
                GlobalScope.launch(Dispatchers.IO) {
                    val usuario=sacoUsuarioDeLaBase(bind.loginNombre.text.toString())
                    if(comprobacion(usuario!!)){
                        if(usuario.tipo=="admin"){
                            SM.idUsuario="admin"
                            val admin=Intent(applicationContext,AdminDrawer::class.java).also{
                                startActivity(it)
                            }
                        }else{
                            SM.idUsuario=usuario.id.toString()
                            val usuario=Intent(applicationContext,UsuarioBottomNav::class.java).also{
                                startActivity(it)
                            }
                        }
                    }else{
                        runOnUiThread {
                            bind.loginError.text=getString(R.string.errorUsuPassIncorrecto)
                        }
                    }
                }
            }
        }


        bind.loginTvRegistrarse.setOnClickListener {
            val registro=Intent(this,Registro::class.java).also {
                startActivity(it)
            }
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        val intent:Intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }


    fun sacoUsuarioDeLaBase(nombrePasado:String):Usuario?{
        var usuario=Usuario()
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.usuarios).orderByChild("login").equalTo(nombrePasado)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        usuario= snapshot.children.iterator().next().getValue(Usuario::class.java)!!
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()

        return usuario

    }

    fun comprobacion(objeto:Usuario):Boolean{
        var pasa=false
            if(objeto.login==bind.loginNombre.text.toString() && objeto.password==bind.loginContrasena.text.toString()){
                pasa=true
            }
        return pasa
    }


    fun validoInput(v:EditText):Boolean{
        var validado=true

        if(v.text.isEmpty()){
            validado=false
            v.error=getString(R.string.campoVacio)
        }

        return validado
    }
}