package com.example.practicafinaljose

class Pedido(val id:String?=null,
             val idcarta:String?=null,
             val idusuario:String?=null,
             val estado:String?="preparacion",
             val fecha:String?=null,
             val notificado:Boolean?=false)