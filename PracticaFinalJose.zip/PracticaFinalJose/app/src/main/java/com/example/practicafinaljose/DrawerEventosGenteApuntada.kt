package com.example.practicafinaljose

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicafinaljose.databinding.FragmentDrawerEventosGenteApuntadaBinding

class DrawerEventosGenteApuntada : Fragment() {
    val ad by lazy {
        activity as AdminDrawer
    }
                          //FragmentNombrefragmento
    private var _binding: FragmentDrawerEventosGenteApuntadaBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentDrawerEventosGenteApuntadaBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    override fun onStart() {
        super.onStart()
        binding.rvGenteApuntada.adapter=ad.adaptadorReserva
        binding.rvGenteApuntada.layoutManager=LinearLayoutManager(ad.applicationContext)
    }

    override fun onResume() {
        super.onResume()
        ad.FAB_manager(5){}
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}