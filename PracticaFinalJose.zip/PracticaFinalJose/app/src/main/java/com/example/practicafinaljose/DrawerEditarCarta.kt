package com.example.practicafinaljose

import android.net.Uri
import android.os.Bundle
import android.system.Os
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.net.toUri
import com.bumptech.glide.Glide
import com.example.practicafinaljose.databinding.FragmentDrawerEditarCartaBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.CountDownLatch

class DrawerEditarCarta : Fragment() {
    val ad by lazy{
        activity as AdminDrawer
    }
    var url_imagen: Uri?=null

    val VBase by lazy {
        VariablesBaseDatos
    }
    val objetoCarta by lazy{
        ad.listaCartas.find { it.id==ad.idCarta }
    }
                          //FragmentNombrefragmento
    private var _binding: FragmentDrawerEditarCartaBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentDrawerEditarCartaBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onStart() {
        super.onStart()
        Glide.with(ad.applicationContext).load(objetoCarta!!.imagen).into(binding.eCartaImagen)
        with(binding){
            eCartaNombre.text=objetoCarta!!.nombre
            eCartaCategoria.text=ad.applicationContext.getString(R.string.cartaCategoria,objetoCarta!!.categoria)
            eCartaPrecio.text=ad.applicationContext.getString(R.string.cartaPrecio,objetoCarta!!.precio.toString())
            eCartaStock.isChecked=objetoCarta!!.disponible!!
        }

    }

    override fun onResume() {
        super.onResume()
        ad.FAB_manager(6,this::editarCarta)
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    fun editarCarta(v:View){

        GlobalScope.launch(Dispatchers.IO) {
            ad.insertoCartaId(objetoCarta!!.id!!,objetoCarta!!.nombre!!,objetoCarta!!.precio!!.toDouble(),objetoCarta!!.imagen!!,binding.eCartaStock.isChecked,objetoCarta!!.categoria!!)
            ad.adaptador.notifyDataSetChanged()
            ad.runOnUiThread{ad.navController.navigate(R.id.drawerCartas)}
        }
    }


}