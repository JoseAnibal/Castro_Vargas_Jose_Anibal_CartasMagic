package com.example.practicafinaljose

import android.content.Context

class SharedManager(val context: Context) {
    val ID = "com.example.practicafinaljose"
    val shared_name = "${ID}_sp"
    val SP = context.getSharedPreferences(shared_name, 0)

    var idUsuario: String
        get() = SP.getString(
            context.getString(R.string.idUsuario),
            context.getString(R.string.idUsuarioDef)
        ) ?: context.getString(R.string.idUsuarioDef)

        set(value) = SP.edit().putString(
            context.getString(R.string.idUsuario),
            value)
            .apply()

    var modoOscuro: Boolean
        get() = SP.getBoolean(
            context.getString(R.string.spModoOscuro),
            context.resources.getBoolean(R.bool.spModoOscuroDef))?:false

        set(value) = SP.edit().putBoolean(
            context.getString(R.string.spModoOscuro),
            value)
            .apply()

    var EUR_USD:String
    get()=SP.getString(
        context.getString(R.string.spMoneda_USD),
        context.getString(R.string.spMoneda_USD_def)
    ) ?: context.getString(R.string.spMoneda_USD_def)

    set(value)=SP.edit().putString(
        context.getString(R.string.spMoneda_USD),
        value)
        .apply()

    var lastReq: String
        get() = SP.getString(
            context.getString(R.string.sp_lastReq),
            context.getString(R.string.sp_lastReq_def)
        ) ?: context.getString(R.string.sp_lastReq_def)

        set(value) = SP.edit().putString(
            context.getString(R.string.sp_lastReq),
            value)
            .apply()

    var EURActivado: Boolean
        get() = SP.getBoolean(
            context.getString(R.string.spEUR),
            context.resources.getBoolean(R.bool.spEURDef))

        set(value) = SP.edit().putBoolean(
            context.getString(R.string.spEUR),
            value)
            .apply()


}