package com.example.practicafinaljose

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.practicafinaljose.databinding.FragmentBottomCartasEnProcesoBinding

class BottomCartasEnProceso : Fragment() {
    val ub by lazy{
        activity as UsuarioBottomNav
    }

    private var _binding: FragmentBottomCartasEnProcesoBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentBottomCartasEnProcesoBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }
    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    override fun onStart() {
        super.onStart()

        binding.rvCartasPendientes.adapter=ub.adaptadorClienteCartaPendiente
        binding.rvCartasPendientes.layoutManager= LinearLayoutManager(ub.applicationContext)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}