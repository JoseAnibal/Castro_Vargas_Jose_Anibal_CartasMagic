package com.example.practicafinaljose

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.practicafinaljose.databinding.FilaPedidoBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.*
import java.util.concurrent.CountDownLatch

class AdaptadorAdminPedido(val lista:List<Pedido>,val contexto:Context):RecyclerView.Adapter<AdaptadorAdminPedido.ViewHolder>(), Filterable {

    var listaFiltrada = lista
    val VBase by lazy {
        VariablesBaseDatos
    }
    val NM by lazy {
        Notificaciones((contexto as AdminDrawer).applicationContext)
    }

    class ViewHolder(val bind: FilaPedidoBinding):RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = FilaPedidoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(v)
    }

    fun sacoUsuarioDeLaBase(idpasado:String):Usuario?{
        var usuario=Usuario()
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.usuarios).orderByChild("id").equalTo(idpasado)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        usuario= snapshot.children.iterator().next().getValue(Usuario::class.java)!!
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()

        return usuario

    }

    fun sacoCartaDeLaBase(idpasado:String):Carta?{
        var cartta:Carta?=null
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.cartas).orderByChild("id").equalTo(idpasado)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        cartta= snapshot.children.iterator().next().getValue(Carta::class.java)!!
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()

        return cartta

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val l = listaFiltrada[position]

        GlobalScope.launch(Dispatchers.IO) {
            val usuario=sacoUsuarioDeLaBase(l.idusuario!!)
            val cartaSacada=sacoCartaDeLaBase(l.idcarta!!)

            (contexto as AdminDrawer).runOnUiThread {
                holder.bind.pCartaNombre.text=cartaSacada!!.nombre.toString()
                holder.bind.pCartaPrecio.text=contexto.getString(R.string.cartaPrecio,cartaSacada.precio.toString())
                holder.bind.pCartaUsuario.text=contexto.getString(R.string.usuarioNomPedido,usuario!!.login.toString())
                holder.bind.pCartaFecha.text=contexto.getString(R.string.eventoFecha,l.fecha)
                Glide.with(contexto).load(cartaSacada.imagen).into(holder.bind.pCartaImagen)
                holder.bind.pCartaAceptar.setOnClickListener {
                    val listaCartas= usuario.cartasObtenidas!!.toMutableList()
                    listaCartas.add(cartaSacada.id!!)
                    insertoPedido(l.id!!,l.idcarta,l.idusuario)
                    insertoUsuarioId(usuario.id!!,usuario.login!!,usuario.password!!,usuario.tipo!!,usuario.imagenUsu!!,usuario.correo!!,listaCartas,true)
                    insertoUsuarioId(usuario.id!!,usuario.login!!,usuario.password!!,usuario.tipo!!,usuario.imagenUsu!!,usuario.correo!!,listaCartas,false)

                }

            }

        }

    }


    fun insertoPedido(id:String,idcarta:String,idusuario:String){
        val crearPedido=Pedido(id,idcarta, idusuario,VBase.pedidoPreparado)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.pedidos).child(id).setValue(crearPedido)
    }

    fun insertoUsuarioId(id:String,login:String,password:String,tipo:String,imagen:String,correo:String,listacartas:MutableList<String>,notificar:Boolean){
        val crearCuenta=Usuario(id,correo,login, password, tipo,imagen,listacartas,notificar)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.usuarios).child(id).setValue(crearCuenta)
    }

    override fun getItemCount(): Int {
        return listaFiltrada.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(busqueda: CharSequence?): FilterResults {
                val texto = busqueda.toString()
                //Filtro 1, el clásico de por nombre, no hace falta pensar
                if (texto.isEmpty()) {
                    listaFiltrada = lista
                } else {
                    val listaFiltrada2 = mutableListOf<Pedido>()
                    for (alu in lista) {
                        val nombreMinuscula = alu.estado!!.lowercase(Locale.ROOT)
                        val textoMinuscula = texto.lowercase(Locale.ROOT)
                        if (nombreMinuscula.contains(textoMinuscula)) {
                            listaFiltrada2.add(alu)
                        }
                    }
                    listaFiltrada = listaFiltrada2
                }
                //FILTROS AQUI

                val filterResults = FilterResults()
                    filterResults.values = listaFiltrada
                    return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                listaFiltrada = results?.values as MutableList<Pedido>
                notifyDataSetChanged()
            }
        }
    }

}