package com.example.practicafinaljose

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.CheckBox
import android.widget.SearchView
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.practicafinaljose.databinding.ActivityUsuarioBottomNavBinding
import com.github.mikephil.charting.data.PieData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.concurrent.CountDownLatch

data class estadisticas(val nombre:String,val porcentaje:Double,val color:Int)


class UsuarioBottomNav : AppCompatActivity() {
    val NM by lazy{
        Notificaciones(this)
    }

    val VBase by lazy{
        VariablesBaseDatos
    }
    val listaCartasDisp by lazy{
        añadoLista()
    }
    val listaCartasPendientes by lazy{
        añadoCartasPendientes()
    }
    val listaEventos by lazy{
        añadoListaEventos()
    }
    val listaEventosApuntado by lazy{
        añadoEventosApuntado()
    }
    val listaCartasObtenidas by lazy{
        todasLasCartasObtenidas()
    }
    val SM by lazy{
        SharedManager(this)
    }
    val adaptadorClienteEventosApuntado by lazy{
        AdaptadorClienteEvento(listaEventosApuntado,this,SM.idUsuario,"apuntado")
    }

    val adaptadorClienteCartaPendiente by lazy{
        AdaptadorClienteCarta(listaCartasPendientes, this,VBase.cartasPendientes)
    }
    val adaptadorClienteCarta by lazy{
        AdaptadorClienteCarta(listaCartasDisp, this,"nada")
    }
    val adaptadorClienteCartasObtenidas by lazy{
        AdaptadorClienteCarta(listaCartasObtenidas, this,VBase.cartasObtenidas)
    }
    val adaptadorClienteEvento by lazy{
        AdaptadorClienteEvento(listaEventos, this,SM.idUsuario,"noapuntado")
    }


    lateinit var navController: NavController
    private lateinit var binding: ActivityUsuarioBottomNavBinding
    lateinit var vistaBottom:BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUsuarioBottomNavBinding.inflate(layoutInflater)
        setContentView(binding.root)

        vistaBottom= binding.navView

        navController = findNavController(R.id.nav_host_fragment_activity_usuario_bottom_nav)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.bottomCartas,R.id.bottomInventario,R.id.bottomEventos
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        NM.createNotificationChannel()
        escuchoUsuarios()
        vistaBottom.setupWithNavController(navController)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.kebab_menu, menu)
        (menu.findItem(R.id.busqueda).actionView as SearchView)
            .setOnQueryTextListener(object: SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(p0: String?): Boolean {
                    return false
                }

                override fun onQueryTextChange(p0: String?): Boolean {
                    adaptadorClienteCarta.filter.filter(p0)
                    return false
                }
            })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.autor ->{
                val intent = Intent(this, Autor::class.java)
                startActivity(intent)
                true
            }
            R.id.cerrarSesion ->{
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                SM.idUsuario=getString(R.string.idUsuarioDef)
                true
            }
            R.id.estadisticas ->{
                navController.navigate(R.id.graficoTarta)
                true
            }
            R.id.ajustes->{
                navController.navigate(R.id.fragmentoAjustes)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onStart() {
        super.onStart()
        if(SM.idUsuario==getString(R.string.idUsuarioDef)){
            val intent=Intent(this,MainActivity::class.java).also {
                startActivity(it)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if(SM.idUsuario==""){
            val intent=Intent(this,MainActivity::class.java).also {
                startActivity(it)
            }
        }
    }

    fun generoReporte():MutableList<estadisticas>{
        var colorNombre= mutableListOf<String>()
        val tipos= mutableListOf<Double>()
        val listaColores= mutableListOf<Int>()

        val reporte= mutableListOf<estadisticas>()
        listaCartasDisp.forEach {
            colorNombre.add(it.categoria!!)
        }
        colorNombre=colorNombre.toSet().toMutableList()
        colorNombre.forEachIndexed { i, e ->
            tipos.add(listaCartasDisp.count{it.categoria==e}.toDouble()/listaCartasDisp.size*100)
            when(e){
                "Blanco"->listaColores.add(Color.rgb(214, 214, 214))
                "Negro"->listaColores.add(Color.rgb(48, 48, 48))
                "Rojo"->listaColores.add(Color.rgb(176, 44, 44))
                "Azul"->listaColores.add(Color.rgb(44, 151, 184))
                "Verde"->listaColores.add(Color.rgb(85, 161, 45))
            }
        }
        colorNombre.forEachIndexed { i, e ->
            reporte.add(estadisticas(e,tipos[i],listaColores[i]))
        }

        return reporte
    }

    fun añadoLista():MutableList<Carta>{
        val lista= mutableListOf<Carta>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.cartas)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val cartta=hijo?.getValue(Carta::class.java)
                        if (cartta != null && cartta.disponible==true) {
                            lista.add(cartta)
                        }

                    }
                    adaptadorClienteCarta.notifyItemChanged(listaCartasDisp.size)
                    adaptadorClienteCarta.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }

    fun añadoCartasPendientes():MutableList<Carta>{
        val lista= mutableListOf<Carta>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.pedidos)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val pediddo=hijo?.getValue(Pedido::class.java)

                        if (pediddo != null) {
                            if(pediddo.estado==VBase.pedidoDef){
                                val cartaAnadir=listaCartasDisp.find { it.id==pediddo.idcarta }
                                if (cartaAnadir != null) {
                                    lista.add(cartaAnadir)
                                }
                            }
                        }

                    }
                    adaptadorClienteCartaPendiente.notifyItemChanged(listaCartasPendientes.size)
                    adaptadorClienteCartaPendiente.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }


    fun añadoListaEventos():MutableList<Evento>{
        val listae= mutableListOf<Evento>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.eventos)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listae.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->
                        val eventto=hijo?.getValue(Evento::class.java)
                        if (eventto != null && (eventto.aforo_max?.minus(eventto.aforo_ocupado!!))!=0) {
                            if(!eventto.gente_apuntada!!.contains(SM.idUsuario)){
                                listae.add(eventto)
                            }
                        }
                    }
                    adaptadorClienteEvento.notifyItemChanged(listaEventos.size)
                    adaptadorClienteEvento.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return listae
    }


    fun todasLasCartasObtenidas():MutableList<Carta>{
        val lista= mutableListOf<Carta>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.usuarios).child(SM.idUsuario).child(VBase.cartasObtenidas)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->
                        val cartta=hijo?.getValue(String::class.java)

                        val cartaAñadir=listaCartasDisp.find { it.id==cartta }
                        if (cartaAñadir != null) {
                            lista.add(cartaAñadir)
                        }
                    }
                    adaptadorClienteCartasObtenidas.notifyItemChanged(listaCartasObtenidas.size)
                    adaptadorClienteCartasObtenidas.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }

    fun añadoEventosApuntado():MutableList<Evento>{
        val listae= mutableListOf<Evento>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.eventos)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listae.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->
                        val eventto=hijo?.getValue(Evento::class.java)
                        if (eventto != null) {
                            if(eventto.gente_apuntada!!.contains(SM.idUsuario)){
                                listae.add(eventto)
                            }
                        }
                    }
                    adaptadorClienteEventosApuntado.notifyItemChanged(listaEventosApuntado.size)
                    adaptadorClienteEventosApuntado.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return listae
    }

    fun escuchoUsuarios(){

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.usuarios)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val usu=hijo?.getValue(Usuario::class.java)
                        if (usu != null && usu.notificado==true && usu.id==SM.idUsuario) {
                            NM.crearNotificacion("Pedido","Un pedido tuyo ha sido aceptado")
                        }

                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
    }

}