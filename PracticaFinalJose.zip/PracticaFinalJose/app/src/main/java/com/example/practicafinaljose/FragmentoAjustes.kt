package com.example.practicafinaljose

import android.R
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.example.practicafinaljose.databinding.FragmentFragmentoAjustesBinding
import org.json.JSONException
import org.json.JSONObject

class FragmentoAjustes : Fragment() {
    val ub by lazy{
        activity as UsuarioBottomNav
    }

    val conversiones by lazy{
        mapOf(
            "USD" to ub.SM.EUR_USD,
            "EUR" to 1
        )
    }

    val conversions_keys by lazy {
        conversiones.keys.toList()
    }
                          //FragmentNombrefragmento
    private var _binding: FragmentFragmentoAjustesBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentFragmentoAjustesBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        val now = System.currentTimeMillis()
        if(shouldMakeRequ(now)){
            ub.SM.lastReq = now.toString()
            makeRequ()
        }
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(com.example.practicafinaljose.R.id.busqueda)
        menu.removeItem(com.example.practicafinaljose.R.id.ajustes)
    }

    override fun onStart() {
        super.onStart()
        binding.ajSwitch.isChecked=ub.SM.modoOscuro

        binding.ajSwitch.setOnClickListener {
            ub.SM.modoOscuro=binding.ajSwitch.isChecked

            if(ub.SM.modoOscuro){
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

        }

        val adaptadorSpi = ArrayAdapter(ub.applicationContext, R.layout.simple_spinner_item,conversions_keys).apply {
            setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
        }

        binding.ajSpinner.adapter = adaptadorSpi
        binding.ajSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                  ub.SM.EURActivado= position==1
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }

    }

    override fun onResume() {
        super.onResume()
        if(ub.SM.EURActivado){
            binding.ajSpinner.setSelection(1)
        }else{
            binding.ajSpinner.setSelection(0)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    fun shouldMakeRequ(now:Long):Boolean{
        val MILIS_IN_DAY=24*60*60*1000
        val last = ub.SM.lastReq.toLong()
        return now-last > MILIS_IN_DAY
    }

    fun makeRequ(){
        val url: String = "https://open.er-api.com/v6/latest/EUR"

        val request = JsonObjectRequest(
            Request.Method.GET, // method
            url, // url
            null, // json request
            { response -> // response listener

                try {
                    val obj: JSONObject = response
                    val data = obj.getJSONObject("rates")
                    ub.SM.EUR_USD = data.getString("USD")
                }catch (e: JSONException){
                }
            },
            { // error listener
            }
        )
        //Hacemos la petición http
        VolleySingleton.getInstance(ub.applicationContext).addToRequestQueue(request)
    }


}