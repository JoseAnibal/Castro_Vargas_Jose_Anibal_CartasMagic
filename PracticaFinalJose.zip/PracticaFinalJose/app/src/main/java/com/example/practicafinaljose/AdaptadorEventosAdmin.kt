package com.example.practicafinaljose

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.practicafinaljose.databinding.FilaEventoBinding
import java.util.*

class AdaptadorEventosAdmin(val lista:List<Evento>,val contexto:Context):RecyclerView.Adapter<AdaptadorEventosAdmin.ViewHolder>(), Filterable {

    var listaFiltrada = lista

    class ViewHolder(val bind: FilaEventoBinding):RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = FilaEventoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val l = listaFiltrada[position]
        Glide.with(contexto).load(l.imagen).into(holder.bind.aEventoImagen)
        with(holder.bind){
            aEventoNombre.text=(contexto as AdminDrawer).getString(R.string.eventoNombre,l.nombre)
            aEventoFecha.text=contexto.getString(R.string.eventoFecha,l.fecha.toString())
            aEventoAforo.text=contexto.getString(R.string.eventoAforo,l.aforo_ocupado.toString(),l.aforo_max.toString())
            aEventoPrecio.text=contexto.getString(R.string.eventoPrecio,l.precio.toString())
        }
        holder.bind.divVerEvento.setOnClickListener {
            (contexto as AdminDrawer).idEvento=l.id!!
            val listaFiltradaReservas=contexto.listaReservas.filter{ it.idEvento==contexto.idEvento }.toMutableList()
            contexto.adaptadorReserva.lista=listaFiltradaReservas
            contexto.navController.navigate(R.id.drawerEventosGenteApuntada)
        }
    }

    override fun getItemCount(): Int {
        return listaFiltrada.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(busqueda: CharSequence?): FilterResults {
                val texto = busqueda.toString()
                //Filtro 1, el clásico de por nombre, no hace falta pensar
                if (texto.isEmpty()) {
                    listaFiltrada = lista
                } else {
                    val listaFiltrada2 = mutableListOf<Evento>()
                    for (alu in lista) {
                        val nombreMinuscula = alu.nombre!!.lowercase(Locale.ROOT)
                        val textoMinuscula = texto.lowercase(Locale.ROOT)
                        if (nombreMinuscula.contains(textoMinuscula)) {
                            listaFiltrada2.add(alu)
                        }
                    }
                    listaFiltrada = listaFiltrada2
                }
                //FILTROS AQUI

                val filterResults = FilterResults()
                    filterResults.values = listaFiltrada
                    return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                listaFiltrada = results?.values as MutableList<Evento>
                notifyDataSetChanged()
            }
        }
    }

}