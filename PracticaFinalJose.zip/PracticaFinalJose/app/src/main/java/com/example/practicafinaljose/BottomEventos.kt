package com.example.practicafinaljose

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicafinaljose.databinding.FragmentBottomEventosBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class BottomEventos : Fragment() {
                          //FragmentNombrefragmento
    private var _binding: FragmentBottomEventosBinding? = null
    val ub by lazy{
        activity as UsuarioBottomNav
    }

    val VBase by lazy {
        VariablesBaseDatos
    }

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentBottomEventosBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onStart() {
        super.onStart()
        binding.evApuntado.setOnClickListener {
            ub.navController.navigate(R.id.bottomEventosApuntado)
        }

        binding.rvEventosCliente.adapter=ub.adaptadorClienteEvento
        binding.rvEventosCliente.layoutManager= LinearLayoutManager(ub.applicationContext)
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}