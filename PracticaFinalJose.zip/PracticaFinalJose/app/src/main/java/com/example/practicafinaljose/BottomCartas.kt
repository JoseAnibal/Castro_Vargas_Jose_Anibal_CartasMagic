import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicafinaljose.R
import com.example.practicafinaljose.Usuario
import com.example.practicafinaljose.UsuarioBottomNav
import com.example.practicafinaljose.databinding.FragmentBottomCartasBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.concurrent.CountDownLatch

class BottomCartas : Fragment() {
    val ub by lazy{
        activity as UsuarioBottomNav
    }
                          //FragmentNombrefragmento
    private var _binding: FragmentBottomCartasBinding? = null
    lateinit var menu: Menu
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentBottomCartasBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    override fun onStart() {
        super.onStart()



        val adaptador = ArrayAdapter(ub.applicationContext,android.R.layout.simple_spinner_item,listOf("Sin filtrado","Negro","Blanco","Rojo","Verde","Azul")).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spiFiltroColor.adapter = adaptador

        binding.spiFiltroColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                ub.adaptadorClienteCarta.filtro=position
                refreshFilter()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }

        binding.rvClienteCarta.adapter=ub.adaptadorClienteCarta
        binding.rvClienteCarta.layoutManager= LinearLayoutManager(ub.applicationContext)
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        this.menu = menu
    }


    override fun onResume() {
        super.onResume()
        ub.adaptadorClienteCarta.filter.filter("")
    }

    fun refreshFilter(){
        val query=(menu.findItem(R.id.busqueda).actionView as SearchView).query
        ub.adaptadorClienteCarta.filter.filter(query)

    }
}