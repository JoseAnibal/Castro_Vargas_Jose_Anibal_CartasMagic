package com.example.practicafinaljose

class Usuario(val id:String?=null,
              val correo:String?=null,
              val login:String?=null,
              val password:String?=null,
              val tipo:String?=null,
              val imagenUsu:String?=null,
              val cartasObtenidas:MutableList<String>?= mutableListOf(),
              val notificado:Boolean?=false)