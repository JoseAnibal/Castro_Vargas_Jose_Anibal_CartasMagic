package com.example.practicafinaljose

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.net.toUri
import com.example.practicafinaljose.databinding.ActivityMainBinding
import com.example.practicafinaljose.databinding.ActivityRegistroBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.CountDownLatch
import java.util.regex.Pattern

class Registro : AppCompatActivity() {
    lateinit var bind:ActivityRegistroBinding
    var url_imagen: Uri?=null
    val VBase by lazy {
        VariablesBaseDatos
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()

        bind.regBtnRegistrarse.setOnClickListener {
            if(isValid() && coincidenContrasenas(bind.regContrasena,bind.regContrasenaN2)){
                val nombre=bind.regNombre.text.toString()
                GlobalScope.launch(Dispatchers.IO) {
                    if(!comprueboSiExiste(nombre)){
                        val password=bind.regContrasena.text.toString()
                        val tipoDefault=VBase.tipoDefault
                        val genero_id= VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.usuarios).push().key
                        val correo=bind.regCorreo.text.toString()
                        val url_imagen_firebase=if(url_imagen!=null){
                            insertoImagen(genero_id.toString(), url_imagen!!)
                        }else{
                            "https://firebasestorage.googleapis.com/v0/b/practicafinaljose-11bf8.appspot.com/o/userDefaultImage.png?alt=media&token=5ee89752-72d8-459f-b408-52cb8defe137"
                        }

                        insertoUsuarioId(genero_id.toString(),nombre,password,tipoDefault,url_imagen_firebase.toString(),correo)
                        val Main= Intent(applicationContext,MainActivity::class.java).also {
                            startActivity(it)
                        }
                    }else{
                        runOnUiThread {
                            bind.regNombre.error="Nombre no disponible"
                        }

                    }
                }

            }
        }

        bind.regImagen.setOnClickListener {
            obtener_url.launch("image/*")
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        val intent= Intent(this,MainActivity::class.java)
        startActivity(intent)

    }

    suspend fun insertoImagen(id:String,foto: Uri):String{

        lateinit var urlImagenFirebase: Uri

        urlImagenFirebase= VBase.sto_ref.child(VBase.ramaPrincipal).child(VBase.stoUsuarios).child(id)
            .putFile(foto).await().storage.downloadUrl.await()

        return urlImagenFirebase.toString()

    }

    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        when (uri){
            null-> {}
            else->{
                url_imagen=uri
                bind.regImagen.setImageURI(url_imagen)

            }
        }
    }

    fun insertoUsuarioId(id:String,login:String,password:String,tipo:String,imagen:String,correo:String){

        val crearCuenta=Usuario(id,correo,login, password, tipo,imagen, mutableListOf())
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.usuarios).child(id).setValue(crearCuenta)

    }

    fun comprueboSiExiste(nombre:String):Boolean{
        var existe=false
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.usuarios).orderByChild("login").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }


    fun isValid():Boolean{
        var validado = true
        val checkers = listOf(
            Pair(bind.regNombre, this::validoCampo),
            Pair(bind.regContrasena, this::validoCampo),
            Pair(bind.regCorreo, this::validoCorreo)
        )
        for(c in checkers){
            val x = c.first
            val f = c.second
            val y = f(x)
            validado = y
            if(!validado) break
        }
        return validado
    }

    fun validoCampo(v:EditText):Boolean{
        var validado=true

        if(v.text.isEmpty()){
            validado=false
            v.error=getString(R.string.campoVacio)
        }

        return validado
    }

    fun validoCorreo(v:EditText):Boolean{
        var validado=true

        if(v.text.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(v.text).matches()){
            validado=false
            v.error="Correo vacio o invalido"
        }

        return validado
    }

    fun coincidenContrasenas(v:EditText,b:EditText):Boolean{
        var validado=true

        if(b.text.toString()!=v.text.toString()){
            validado=false
            b.error="Contraseña no coincide"
        }

        return validado
    }

}
