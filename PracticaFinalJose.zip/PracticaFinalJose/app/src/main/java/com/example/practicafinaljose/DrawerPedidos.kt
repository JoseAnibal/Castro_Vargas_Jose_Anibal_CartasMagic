package com.example.practicafinaljose

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicafinaljose.databinding.FragmentDrawerPedidosBinding

class DrawerPedidos : Fragment() {
    val ad by lazy{
        activity as AdminDrawer
    }


                          //FragmentNombrefragmento
    private var _binding: FragmentDrawerPedidosBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentDrawerPedidosBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onStart() {
        super.onStart()
        binding.rvAdminPedidos.adapter=ad.adaptadorPedidos
        binding.rvAdminPedidos.layoutManager= LinearLayoutManager(ad.applicationContext)
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onResume() {
        super.onResume()
        ad.FAB_manager(5){}
    }
}