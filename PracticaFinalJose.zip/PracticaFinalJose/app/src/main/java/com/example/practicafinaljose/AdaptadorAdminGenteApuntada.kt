package com.example.practicafinaljose

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.practicafinaljose.databinding.FilaGenteapuntadaBinding
import java.util.*

class AdaptadorAdminGenteApuntada(var lista:MutableList<ReservasEventos>, val contexto: Context): RecyclerView.Adapter<AdaptadorAdminGenteApuntada.ViewHolder>() {

    val options = RequestOptions ()
        .fallback(R.drawable.nostock)
        .error(R.drawable.nostock)
        .circleCrop()

    class ViewHolder(v: View): RecyclerView.ViewHolder(v){
    //EmpiezaEnMayuscula
        val bind = FilaGenteapuntadaBinding.bind(v)
    }
                                                                       //Recycler.ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptadorAdminGenteApuntada.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_genteapuntada,parent,false)
        return ViewHolder(v)
    }
                                        //Recycler.ViewHolder
    override fun onBindViewHolder(holder: AdaptadorAdminGenteApuntada.ViewHolder, position: Int) {
        val l = lista[position]
        val usuarioApuntados=(contexto as AdminDrawer).listaUsuarios.find { it.id==l.idUsuario }
        with(holder.bind){
            gaNombre.text=usuarioApuntados!!.login
        }
        Glide.with(contexto).load(usuarioApuntados!!.imagenUsu).apply(options).into(holder.bind.gaFoto)
    }

    override fun getItemCount(): Int {
        return lista.size
    }


}