package com.example.practicafinaljose

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicafinaljose.databinding.FragmentDrawerEventosBinding

class DrawerEventos : Fragment() {
    val ad by lazy{
        activity as AdminDrawer
    }
                          //FragmentNombrefragmento
    private var _binding: FragmentDrawerEventosBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
                   //FragmentNombrefragmento
        _binding = FragmentDrawerEventosBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


    override fun onStart() {
        super.onStart()
        binding.rvEventosAdmin.adapter=ad.adaptadorEvento
        binding.rvEventosAdmin.layoutManager= LinearLayoutManager(ad.applicationContext)
    }

    override fun onResume() {
        super.onResume()
        ad.adaptadorEvento.filter.filter("")
        ad.FAB_manager(3){}
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}