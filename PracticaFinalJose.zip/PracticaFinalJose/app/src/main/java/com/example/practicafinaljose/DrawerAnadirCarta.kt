package com.example.practicafinaljose

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import com.example.practicafinaljose.databinding.FragmentDrawerAnadirCartaBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.CountDownLatch

class DrawerAnadirCarta : Fragment() {
    val ad by lazy{
        activity as AdminDrawer
    }
    var url_imagen: Uri?=null

    val VBase by lazy {
        VariablesBaseDatos
    }

    private var _binding: FragmentDrawerAnadirCartaBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentDrawerAnadirCartaBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onStart() {
        super.onStart()

        binding.cCartaError.visibility=View.INVISIBLE
        binding.cCartaImagen.setOnClickListener {
            obtener_url.launch("image/*")
        }

        val adaptadorSpi = ArrayAdapter(ad.applicationContext,android.R.layout.simple_spinner_item,ad.listaSpinner).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.cCartaSpi.adapter = adaptadorSpi
    }

    override fun onResume() {
        super.onResume()
        ad.FAB_manager(2,this::InsertarCarta)
    }

    fun InsertarCarta(v:View){
        if (isValid() && validoImagen(url_imagen)){
            val nombre=binding.cCartaNombre.text.toString()
            GlobalScope.launch(Dispatchers.IO) {
                if(!comprueboSiExiste(nombre)){
                    val genero_id= VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.cartas).push().key
                    val precio=binding.cCartaPrecio.text.toString().toDouble()
                    val categoria=ad.nombreCategoria()[binding.cCartaSpi.selectedItemPosition]
                    val url_imagen_firebase= insertoImagen(genero_id.toString(), url_imagen!!)

                    val disponible=binding.cCartaStock.isChecked
                    ad.insertoCartaId(genero_id.toString(),nombre,precio,url_imagen_firebase,disponible,categoria)
                    ad.adaptador.notifyItemChanged(ad.listaCartas.size)
                    ad.adaptador.notifyDataSetChanged()
                    ad.runOnUiThread{ad.navController.navigate(R.id.drawerCartas)}
                }else{
                    ad.runOnUiThread {
                        binding.cCartaNombre.error="Nombre no disponible"
                    }

                }
            }
        }
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)
        menu.removeItem(R.id.busqueda)
    }

    suspend fun insertoImagen(id:String,foto: Uri):String{

        lateinit var urlImagenFirebase: Uri

        urlImagenFirebase= VBase.sto_ref.child(VBase.ramaPrincipal).child(VBase.stoCartas).child(id)
            .putFile(foto).await().storage.downloadUrl.await()

        return urlImagenFirebase.toString()

    }

    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri: Uri?->
        when (uri){
            null-> {}
            else->{
                url_imagen=uri
                binding.cCartaImagen.setImageURI(url_imagen)

            }
        }
    }


    fun comprueboSiExiste(nombre:String):Boolean{
        var existe=false
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.cartas).orderByChild("nombre").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }

    fun isValid():Boolean{
        var validado = true
        val checkers = listOf(
            Pair(binding.cCartaNombre, this::validoInput),
            Pair(binding.cCartaPrecio, this::validoMayor0)
        )
        for(c in checkers){
            val x = c.first
            val f = c.second
            val y = f(x)
            validado = y
            if(!validado) break
        }
        return validado
    }

    fun validoInput(v: EditText):Boolean{
        var validado=true

        if(v.text.isEmpty()){
            validado=false
            v.error=getString(R.string.campoVacio)
        }

        return validado
    }

    fun validoMayor0(v: EditText):Boolean{
        var validado=true

        if(v.text.isEmpty() || v.text.toString().toDouble()<=0){
            validado=false
            v.error="Precio vacio o menor que 0"
        }

        return validado
    }

    fun validoImagen(laUrl:Uri?):Boolean{
        var validado=true

        if(laUrl==null){
            validado=false
            binding.cCartaError.visibility=View.VISIBLE
        }

        return validado
    }
}