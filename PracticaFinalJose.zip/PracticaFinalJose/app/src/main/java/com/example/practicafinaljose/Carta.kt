package com.example.practicafinaljose

class Carta(val id:String?=null,
            val nombre:String?=null,
            val precio:Double?=null,
            val imagen:String?=null,
            val disponible:Boolean?=false,
            val categoria:String?=null) {

}