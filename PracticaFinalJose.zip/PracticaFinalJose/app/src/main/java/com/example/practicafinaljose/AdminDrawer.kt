package com.example.practicafinaljose

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.SearchView
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicafinaljose.databinding.ActivityAdminDrawerBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger

class AdminDrawer : AppCompatActivity() {
    val NM by lazy {
        Notificaciones(this)
    }
    val SM by lazy {
        SharedManager(this)
    }
    val VBase by lazy{
        VariablesBaseDatos
    }
    val listaSpinner by lazy{
        nombreCategoria()
    }
    val listaCategoria by lazy{
        imagenesCategoria()
    }
    //EVENTOS
    val listaEventos by lazy{
        añadoListaEventos()
    }
    val adaptadorEvento by lazy{
        AdaptadorEventosAdmin(listaEventos, this)
    }
    //RESERVAS EVENTOS
    lateinit var listaReservas:MutableList<ReservasEventos>

    val adaptadorReserva by lazy{
        AdaptadorAdminGenteApuntada(listaReservas, this)
    }

    //CARTAS
    val listaCartas by lazy{
        añadoLista()
    }
    val adaptador by lazy{
        AdaptadorCartas(listaCartas, this)
    }
    //PEDIDOS
    val listaPedidos by lazy{
        añadoPedidos()
    }
    val adaptadorPedidos by lazy{
        AdaptadorAdminPedido(listaPedidos, this)
    }

    var idCarta=""
    var idEvento=""

    lateinit var listaUsuarios:MutableList<Usuario>
    lateinit var navController:NavController
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityAdminDrawerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.appBarAdminDrawer.toolbar)

        FAB_manager(1) {}
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        establecerUsuario()
        navController = findNavController(R.id.nav_host_fragment_content_admin_drawer)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.drawerCartas,R.id.drawerEventos,R.id.drawerPedidos
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        NM.createNotificationChannel()
        escuchoPedidos()
        listaUsuarios=sacotodosUsuarios()
        listaReservas=sacoReservasEventos()
        navView.setupWithNavController(navController)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.kebab_menu, menu)
        menu.removeItem(R.id.ajustes)
        menu.removeItem(R.id.estadisticas)
        (menu.findItem(R.id.busqueda).actionView as SearchView)
            .setOnQueryTextListener(object: SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(p0: String?): Boolean {
                    return false
                }

                override fun onQueryTextChange(p0: String?): Boolean {
                    adaptador.filter.filter(p0)
                    adaptadorEvento.filter.filter(p0)
                    return false
                }
            })
        return true
    }


    override fun onStart() {
        super.onStart()
        if(SM.idUsuario!="admin"){
            val intent=Intent(this,MainActivity::class.java).also {
                startActivity(it)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.cerrarSesion ->{
                SM.idUsuario=getString(R.string.idUsuarioDef)
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.autor->{
                val intent = Intent(this, Autor::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_admin_drawer)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    fun nombreCategoria():List<String>{
        return listOf("Negro","Blanco","Rojo","Verde","Azul")
    }
    fun imagenesCategoria():List<Int>{
        return listOf(R.drawable.negro,R.drawable.blancopng,R.drawable.rojo,R.drawable.verde,R.drawable.azul)
    }

    fun añadoLista():MutableList<Carta>{
        val lista= mutableListOf<Carta>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.cartas)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val cartta=hijo?.getValue(Carta::class.java)
                        if (cartta != null) {
                            lista.add(cartta)
                        }
                    }
                    adaptador.notifyItemChanged(listaCartas.size)
                    adaptador.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }

    fun añadoListaEventos():MutableList<Evento>{
        val listae= mutableListOf<Evento>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.eventos)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listae.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val eventto=hijo?.getValue(Evento::class.java)
                        if (eventto != null) {
                            listae.add(eventto)
                        }
                    }
                    adaptadorEvento.notifyItemChanged(listaEventos.size)
                    adaptadorEvento.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return listae
    }

    fun añadoPedidos():MutableList<Pedido>{
        val lista= mutableListOf<Pedido>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.pedidos)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val pediddo=hijo?.getValue(Pedido::class.java)
                        if (pediddo != null && pediddo.estado==VBase.pedidoDef) {
                            lista.add(pediddo)

                        }
                    }
                    adaptadorPedidos.notifyItemChanged(listaPedidos.size)
                    adaptadorPedidos.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }

    fun escuchoPedidos(){
        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.pedidos)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val pediddo=hijo?.getValue(Pedido::class.java)
                        if (pediddo != null && pediddo.notificado==true && SM.idUsuario=="admin") {
                            NM.crearNotificacion("Nuevo pedido recibido","Tienes un nuevo pedido")
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
    }

    fun sacoReservasEventos():MutableList<ReservasEventos>{
        var lista= mutableListOf<ReservasEventos>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.reservaEvento)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val eventto=hijo?.getValue(ReservasEventos::class.java)
                        if (eventto != null) {
                            lista.add(eventto)
                        }
                    }
                    adaptadorReserva.notifyItemChanged(listaReservas.size)
                    adaptadorReserva.notifyDataSetChanged()

                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }

    fun sacotodosUsuarios():MutableList<Usuario>{
        var lista= mutableListOf<Usuario>()

        VBase.db_ref.child(VBase.ramaPrincipal)
            .child(VBase.usuarios)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val usuarrio=hijo?.getValue(Usuario::class.java)
                        if (usuarrio != null) {
                            lista.add(usuarrio)
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        return lista
    }

    fun FAB_manager(mode:Int, listener:(View)->Unit){
        when(mode){
            1 -> {
                binding.appBarAdminDrawer.fab.show()
                (binding.appBarAdminDrawer.fab).apply{
                    setImageResource(R.drawable.ic_baseline_add_24)
                    setOnClickListener { view ->
                        navController.navigate(R.id.drawerAnadirCarta)
                    }
                }
            }
            2 -> {
                binding.appBarAdminDrawer.fab.show()
                (binding.appBarAdminDrawer.fab).apply{
                    setImageResource(R.drawable.ic_baseline_send_24)
                    //CARTASAÑADIR
                    setOnClickListener(listener)
                }
            }
            3 -> {
                binding.appBarAdminDrawer.fab.show()
                (binding.appBarAdminDrawer.fab).apply{
                    setImageResource(R.drawable.ic_baseline_add_24)
                    setOnClickListener { view ->
                        navController.navigate(R.id.drawerAnadirEventos)
                    }
                }
            }

            4 -> {
                binding.appBarAdminDrawer.fab.show()
                (binding.appBarAdminDrawer.fab).apply{
                    setImageResource(R.drawable.ic_baseline_send_24)
                    //EVENTOSAÑADIR
                    setOnClickListener(listener)
                }
            }

            5 -> {
                //NO HACE NA
                binding.appBarAdminDrawer.fab.hide()
            }

            6->{
                binding.appBarAdminDrawer.fab.show()
                (binding.appBarAdminDrawer.fab).apply{
                    setImageResource(R.drawable.ic_baseline_save_24)
                    //CARTASMODIFICAR
                    setOnClickListener(listener)
                }
            }

        }
    }

    fun insertoCartaId(id:String,nombre:String,precio:Double,imagen:String,disponible:Boolean,categoria:String){

        val crearCarta=Carta(id,nombre, precio, imagen, disponible, categoria)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.cartas).child(id).setValue(crearCarta)

    }

    fun insertoEvento(id:String,nombre:String,imagen:String,precio:String,aforo_max:Int,aforo_ocupado:Int,fecha:String){

        val crearEvento=Evento(id, nombre, imagen, precio, aforo_max, aforo_ocupado,
            mutableListOf(),fecha)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.eventos).child(id).setValue(crearEvento)

    }

    fun establecerUsuario(){
        val v=binding.navView.getHeaderView(0)
        v.findViewById<TextView>(R.id.adminNombre).text = "Administrador"
    }


}