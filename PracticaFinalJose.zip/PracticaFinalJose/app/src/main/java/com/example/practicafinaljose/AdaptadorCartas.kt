package com.example.practicafinaljose

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.practicafinaljose.databinding.FilaCartaBinding
import java.util.*

class AdaptadorCartas(val lista:MutableList<Carta>,val contexto:Context):RecyclerView.Adapter<AdaptadorCartas.ViewHolder>(), Filterable {

    var listaFiltrada = lista

    class ViewHolder(val bind: FilaCartaBinding):RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = FilaCartaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val l = listaFiltrada[position]
        val stock= listOf(R.drawable.nostock,R.drawable.stock)
        var elegida=R.drawable.nostock

        with(holder.bind){
            vCartaNombre.text=l.nombre
            vCartaPrecio.text=(contexto as AdminDrawer).getString(R.string.cartaPrecio,l.precio.toString())
            vCartaCategoriaText.text=contexto.getString(R.string.cartaCategoria,l.categoria.toString())
            vCartaStock.setImageResource(if (l.disponible!!){stock[1]}else{stock[0]})
            when(l.categoria){
                "Blanco"->elegida=R.drawable.blancopng
                "Negro"->elegida=R.drawable.negro
                "Rojo"->elegida=R.drawable.rojo
                "Verde"->elegida=R.drawable.verde
                "Azul"->elegida=R.drawable.azul
            }
            vCartaCategoria.setImageResource(elegida)
        }
        holder.bind.divVerCarta.setOnClickListener {
            (contexto as AdminDrawer).apply {
                idCarta= l.id!!
                navController.navigate(R.id.drawerEditarCarta)
            }
        }
        Glide.with(contexto).load(l.imagen).into(holder.bind.vCartaImagen)
    }

    override fun getItemCount(): Int {
        return listaFiltrada.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(busqueda: CharSequence?): FilterResults {
                val texto = busqueda.toString()
                //Filtro 1, el clásico de por nombre, no hace falta pensar
                listaFiltrada = if (texto.isEmpty()) {
                    lista
                } else {
                    val listaFiltrada2 = mutableListOf<Carta>()
                    for (alu in lista) {
                        val nombreMinuscula = alu.nombre!!.lowercase(Locale.ROOT)
                        val textoMinuscula = texto.lowercase(Locale.ROOT)
                        if (nombreMinuscula.contains(textoMinuscula)) {
                            listaFiltrada2.add(alu)
                        }
                    }
                    listaFiltrada2
                }
                //FILTROS AQUI

                val filterResults = FilterResults()
                    filterResults.values = listaFiltrada
                    return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                listaFiltrada = results?.values as MutableList<Carta>
                notifyDataSetChanged()
            }
        }
    }

}