package com.example.practicafinaljose

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.practicafinaljose.databinding.FilaClienteEventoBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.*
import java.util.concurrent.CountDownLatch

class AdaptadorClienteEvento(val lista:List<Evento>,val contexto:Context,val usuID:String,val info:String):RecyclerView.Adapter<AdaptadorClienteEvento.ViewHolder>(), Filterable {
    val VBase by lazy {
        VariablesBaseDatos
    }
    val SM by lazy{
        SharedManager((contexto as UsuarioBottomNav).applicationContext)
    }
    var listaFiltrada = lista
    class ViewHolder(val bind: FilaClienteEventoBinding):RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = FilaClienteEventoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val l = listaFiltrada[position]
        var euro=SM.EURActivado
        if(info=="apuntado"){
            holder.bind.cvEventoApuntarse.apply {
                visibility=View.GONE
                isEnabled=false
            }
        }

        if(!euro){
            val conversion=SM.EUR_USD.toDouble()
            val precio=conversion*l.precio!!.toDouble()
            holder.bind.cvEventoPrecio.text=contexto.getString(R.string.eventoPrecioDollar,precio.toString())
        }else{
            holder.bind.cvEventoPrecio.text=contexto.getString(R.string.eventoPrecio,l.precio.toString())
        }
        with(holder.bind){
            cvEventoAforo.text=(contexto as UsuarioBottomNav).getString(R.string.eventoAforo,l.aforo_ocupado.toString(),l.aforo_max.toString())
            cvEventoNombre.text=contexto.getString(R.string.eventoNombre,l.nombre)
            cvEventoFecha.text=contexto.getString(R.string.eventoFecha,l.fecha.toString())
        }

        holder.bind.cvEventoApuntarse.setOnClickListener {
            val genero_id= VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.reservaEvento).push().key
            GlobalScope.launch(Dispatchers.IO) {
                val listaDeGente=sacoEventoDeLaBase(l.id!!)!!.gente_apuntada!!.toMutableList()
                if(!listaDeGente.contains(usuID)){
                    listaDeGente.add(usuID)
                    insertoEvento(l.id,l.nombre!!,l.imagen!!,l.precio!!,l.aforo_max!!,listaDeGente.count(),listaDeGente,l.fecha!!)
                    insertoReserva(genero_id!!,l.id,usuID)
                }
            }
        }
        Glide.with(contexto).load(l.imagen).into(holder.bind.cvEventoImagen)
    }

    fun insertoEvento(id:String,nombre:String,imagen:String,precio:String,aforo_max:Int,aforo_ocupado:Int,listaActualizada:MutableList<String>,fecha:String){

        val crearEvento=Evento(id, nombre, imagen, precio, aforo_max, aforo_ocupado,listaActualizada,fecha)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.eventos).child(id).setValue(crearEvento)

    }

    fun sacoEventoDeLaBase(idevento:String):Evento?{
        var evennto:Evento?=null
        val semaforo= CountDownLatch(1)

        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.eventos).orderByChild("id").equalTo(idevento)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        evennto= snapshot.children.iterator().next().getValue(Evento::class.java)!!
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()

        return evennto

    }

    fun insertoReserva(id:String,idevento: String,idUsuario: String){

        val crearReserva=ReservasEventos(id,idevento,idUsuario)
        VBase.db_ref.child(VBase.ramaPrincipal).child(VBase.reservaEvento).child(id).setValue(crearReserva)

    }


    override fun getItemCount(): Int {
        return listaFiltrada.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(busqueda: CharSequence?): FilterResults {
                val texto = busqueda.toString()
                //Filtro 1, el clásico de por nombre, no hace falta pensar
                if (texto.isEmpty()) {
                    listaFiltrada = lista
                } else {
                    val listaFiltrada2 = mutableListOf<Evento>()
                    for (alu in lista) {
                        val nombreMinuscula = alu.nombre!!.lowercase(Locale.ROOT)
                        val textoMinuscula = texto.lowercase(Locale.ROOT)
                        if (nombreMinuscula.contains(textoMinuscula)) {
                            listaFiltrada2.add(alu)
                        }
                    }
                    listaFiltrada = listaFiltrada2
                }
                //FILTROS AQUI

                val filterResults = FilterResults()
                    filterResults.values = listaFiltrada
                    return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                listaFiltrada = results?.values as MutableList<Evento>
                notifyDataSetChanged()
            }
        }
    }

}