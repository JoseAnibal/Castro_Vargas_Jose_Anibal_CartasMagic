package com.example.practicafinaljose

class Evento(val id:String?=null,
             val nombre:String?=null,
             val imagen:String?=null,
             val precio:String?=null,
             val aforo_max:Int?=1,
             val aforo_ocupado:Int?=0,
             val gente_apuntada:MutableList<String>?= mutableListOf(),
             val fecha:String?=null)